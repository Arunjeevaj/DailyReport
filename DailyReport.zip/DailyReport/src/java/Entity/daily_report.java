/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.sql.Date;

/**
 *
 * @author Anand
 */
public class daily_report {
    
    private String employee_name;
    private Date task_date;
    private String work_status;
    private  String task_assigned;
    private int task_code;
    private String remark;

    public String getRemark() {
        return remark;
    }

  

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public int getTask_code() {
        return task_code;
    }

    public void setTask_code(int task_code) {
        this.task_code = task_code;
    }

    public String getWork_status() {
        return work_status;
    }

    public void setWork_status(String work_status) {
        this.work_status = work_status;
    }

    public String getEmployee_name() {
        return employee_name;
    }

    public void setEmployee_name(String employee_name) {
        this.employee_name = employee_name;
    }

    public Date getTask_date() {
        return task_date;
    }

    public void setTask_date(Date task_date) {
        this.task_date = task_date;
    }

    public String getTask_assigned() {
        return task_assigned;
    }

    public void setTask_assigned(String task_assigned) {
        this.task_assigned = task_assigned;
    }
    
    
    
    
    
    
    
}
