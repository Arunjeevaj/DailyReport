/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;
import Entity.AllotedTable;
import java.io.IOException;
import java.sql.*;
import com.DBConnection;
import com.DWA_Constants;
import java.util.List;
/**
 *
 * @author Anand
 */
public class AllotedTableManager {
    
    
    public void Add_Allotedtable(List<AllotedTable> tables) throws SQLException,IOException, ClassNotFoundException
    {
        
        DBConnection db=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
        String sql="insert into allocation_table(Project_Code,Employee_Name,Module_Name,Alocated_date,End_date) values(?,?,?,?,?)";
        PreparedStatement ps=db.prepare(sql);
        for(AllotedTable a:tables){
        ps.setInt(1,a.getProject_code());
        ps.setString(2,a.getEmployee_name());
        ps.setString(3,a.getModule_name());
        ps.setDate(4,a.getStart_date());
        ps.setDate(5,a.getEnd_date());
        ps.addBatch();
        }
        ps.executeBatch();
        ps.close();
        db.close();
        
    }   
    
    
    
    
    
    
}
