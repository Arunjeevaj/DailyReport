/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import Entity.Employee;
import com.DBConnection;
import com.DWA_Constants;
import java.sql.SQLException;
import java.util.List;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author Anand
 */
public class EmployeeManager {
    
    public List<Employee> loadEmployee() throws ClassNotFoundException,SQLException{
        DBConnection db=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
        List<Employee> l1=new ArrayList<Employee>();
        PreparedStatement ps=db.prepare("select * from emp_details");
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            Employee em=new Employee();
            em.setEmployeename(rs.getString(2));
            l1.add(em);
        }
        return l1;
    }


public List<String>findEmployee(String term) throws ClassNotFoundException,SQLException
{

    DBConnection db=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
    String data="";
    List<String> li=new ArrayList<String>();
    PreparedStatement ps=db.prepare("select * from emp_details where EmployeeName like ?");
    ps.setString(1, term+"%");
    ResultSet rs=ps.executeQuery();
    while(rs.next())
    {
        data=rs.getString(2);
        li.add(data);
    }
    
    
    
   return li; 
}

}