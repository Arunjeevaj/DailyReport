/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import java.sql.SQLException;
import com.DBConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Entity.Login;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Anand
 */
public class LoginManager {

    public boolean Checkuser(Login l) throws SQLException, ClassNotFoundException {

        DBConnection con = new DBConnection("job_analyzer");
        String sql = "select * from  `login` where `Uname`=? and `Password`=?";

        PreparedStatement ps = con.prepare(sql);
        ps.setString(1, l.getUname());
        ps.setString(2, l.getPassword());
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            return true;
        }

        ps.close();
        con.close();
        return false;

    }

    public List<Login> getUser() throws SQLException, IOException, ClassNotFoundException {

        DBConnection con = new DBConnection("job_analyzer");
        String sql = "Select * from `login`";
        PreparedStatement ps = con.prepare(sql);
        ResultSet rs = ps.executeQuery();
        List<Login> l = new ArrayList<Login>();
        while (rs.next()) {
            Login login = new Login();
            login.setLoginid(rs.getInt(1));
            login.setUname(rs.getString(2));
            login.setPassword(rs.getString(3));
            l.add(login);
        }

        return l;

    }

}
