/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;
import Entity.daily_report;
import java.io.IOException;
import java.sql.SQLException;
import com.DBConnection;
import com.DWA_Constants;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Anand
 */
public class dailyreportmanager {
    
    
 public void addreport(daily_report d) throws SQLException,IOException, ClassNotFoundException
 {
     
    DBConnection con=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
    String sql="insert into create_report(employee_name,project_date,task_assigned,work_status,month)values(?,?,?,?)";
    PreparedStatement ps=con.prepare(sql);
    ps.setString(1,d.getEmployee_name());
    ps.setDate(2,d.getTask_date());
    ps.setString(3,d.getTask_assigned());
    ps.setString(4,d.getWork_status());
  
    ps.executeUpdate();
    ps.close();
    con.close();
    
     
     
     
     
 }
 
 
 
 public List<daily_report>getmonthlyreport(int month,String name)throws SQLException,IOException,ClassNotFoundException
 {
     
     DBConnection con=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
     String sql="select * from create_report where MONTH(`project_date`)=? and employee_name=?";
     PreparedStatement ps=con.prepare(sql);
     ps.setInt(1,month);
     ps.setString(2,name);
     List<daily_report> li=new ArrayList<daily_report>();
     ResultSet rs=ps.executeQuery();
     while(rs.next())
     {
         daily_report d=new daily_report();
         d.setEmployee_name(rs.getString(2));
         d.setTask_date(rs.getDate(3));
             d.setWork_status(rs.getString(4));
         d.setTask_assigned(rs.getString(5));
         d.setRemark(rs.getString(6));
           li.add(d);
     }
     
     return li;
 }
 
    
 
 public List<daily_report>getreport() throws SQLException,IOException,ClassNotFoundException
 {
     DBConnection con=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
     String sql="select * from create_report";
     PreparedStatement ps=con.prepare(sql);
     List<daily_report> li=new ArrayList<daily_report>();
     ResultSet rs=ps.executeQuery();
     while(rs.next())
     {
         daily_report d=new daily_report();
         d.setEmployee_name(rs.getString(2));
         d.setTask_date(rs.getDate(3));
         d.setWork_status(rs.getString(4));
         d.setTask_assigned(rs.getString(5));
         d.setRemark(rs.getString(6));
         li.add(d);
        }
     
     return li;
 }
 
 
 
 
 public List<daily_report> viewpendingreport() throws SQLException,IOException,ClassNotFoundException
 {
     
     DBConnection con2=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
     String sql="select * from create_report where work_status='Pending'";
     List<daily_report> l1=new ArrayList<daily_report>();
     PreparedStatement ps= con2.prepare(sql);
     ResultSet rs= ps.executeQuery();
     while(rs.next())
     {
         
         daily_report d=new daily_report();
         d.setEmployee_name(rs.getString(2));
         d.setTask_date(rs.getDate(3));
         l1.add(d);
         
     }
       
     return l1;
     
 }
 
 
 public void updatereport(daily_report d) throws SQLException,IOException,ClassNotFoundException
 {
     
     DBConnection con=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
     String sql="update create_report set work_status=?,remarks=? where task_code=?";
    PreparedStatement ps=con.prepare(sql);
    ps.setString(1,d.getWork_status());
    ps.setString(2, d.getRemark());
     ps.setInt(3, d.getTask_code());
     ps.executeUpdate();
     ps.close();
    con.close();
      
 }
    
 
 public List<daily_report> findEmployeeByName(String name)throws SQLException,IOException, ClassNotFoundException
 {
     DBConnection con=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
     List<daily_report> li=new ArrayList<daily_report>();
     String sql="select * from create_report where employee_name=?";
     PreparedStatement ps=con.prepare(sql);
     ps.setString(1,name);
    ResultSet rs= ps.executeQuery();
    while(rs.next())
    {
        daily_report dp=new daily_report();
        dp.setTask_code(rs.getInt(1));
        dp.setEmployee_name(rs.getString(2));
        dp.setTask_date(rs.getDate(3));
        dp.setWork_status(rs.getString(4));
        dp.setTask_assigned(rs.getString(5));
        dp.setRemark(rs.getString(6));
        li.add(dp);
    }
    rs.close();
    ps.close();
    con.close();
    return li;
 }
    

 public List<daily_report> findEmployeeByDate(Date d)throws SQLException,IOException, ClassNotFoundException
 {
     DBConnection con=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
     List<daily_report> li=new ArrayList<daily_report>();
     String sql="select * from `create_report` where project_date=?";
     PreparedStatement ps=con.prepare(sql);
                              System.out.println("date is " +d);

     ps.setDate(1,d);
    ResultSet rs= ps.executeQuery();
    System.out.println("resultset---------"+ps);
    while(rs.next())
    {
        
        daily_report dp=new daily_report();
        dp.setTask_code(rs.getInt(1));
        dp.setEmployee_name(rs.getString(2));
        dp.setTask_date(rs.getDate(3));
        dp.setWork_status(rs.getString(4));
        dp.setTask_assigned(rs.getString(5));
        dp.setRemark(rs.getString(6));
        li.add(dp);
    }
    rs.close();
    ps.close();
    con.close();
    return li;
 }
    
}