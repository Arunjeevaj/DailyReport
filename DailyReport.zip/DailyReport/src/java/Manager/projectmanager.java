/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import Entity.Employee;
import java.io.IOException;
import java.sql.SQLException;
import Entity.project;
import com.DBConnection;
import java.sql.PreparedStatement;
import com.DWA_Constants;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Anand
 */
public class projectmanager {
    
    
    public void addproject(project p) throws SQLException,IOException, ClassNotFoundException
    {
        
        DBConnection con=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
        String sql="insert into create_report(employee_name,project_date,work_status,task_assigned) values(?,?,?,?)";
        PreparedStatement ps=con.prepare(sql);
        ps.setString(1,p.getPname());
        ps.setString(2, p.getPdetails());
        ps.setDate(3, p.getSdate());
        ps.setDate(4, p.getEdate());
        ps.executeUpdate();
        
        
        
        
    }
    
    public List<project> loadProject() throws ClassNotFoundException,SQLException{
        DBConnection db=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
        String sql="select * from create_project";
        PreparedStatement ps=db.prepare(sql);
        List<project> pl=new ArrayList<project>();
        
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            project p=new project();
            p.setProject_id(rs.getInt(1));
            p.setPname(rs.getString(2));
            p.setPdetails(rs.getString(3));
            p.setSdate(rs.getDate(4));
            p.setEdate(rs.getDate(5));
            pl.add(p);
           
        }
        rs.close();
        ps.close();
        db.close();
       return pl;
    }
    
   public List<project> loadProjectDetails(int id) throws ClassNotFoundException,SQLException{
       DBConnection db=new DBConnection(DWA_Constants.JOB_ANALYZER_DB);
       List<project> project=new ArrayList<project>();
       String sql="select `project_code`,`project_name`,`start_date`,`end_date`,`EmployeeName`,`WorkStatus` from "
               + "create_project LEFT JOIN emp_details"
               + " ON create_project.project_code=emp_details.ProjectCode "
               + "where project_code=?";
       PreparedStatement ps=db.prepare(sql);
       ps.setInt(1, id);
       System.out.println(ps);
       ResultSet rs=ps.executeQuery();
       while(rs.next()){
           project p=new project();
           Employee employee=new Employee();
           p.setProject_id(rs.getInt(1));
           p.setPname(rs.getString(2));
           p.setSdate(rs.getDate(3));
           p.setEdate(rs.getDate(4));
           employee.setEmployeename(rs.getString(5));
           employee.setWork_status(rs.getInt(6));
           p.setEmployee(employee);
           project.add(p);
           
       }
       db.close();
       ps.close();
       rs.close();
       return project;
   }
    
    public static void main(String[] args) {
        try {
            new projectmanager().loadProjectDetails(2);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(projectmanager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(projectmanager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
