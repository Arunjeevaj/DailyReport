/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author Anand
 */
public class Convert_S_D {
    public static Date getSDate(String date) throws ParseException{
             SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parse = df.parse(date);
            java.sql.Date sdate = new java.sql.Date(parse.getTime());
            return sdate;
    }
}
