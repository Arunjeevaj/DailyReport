/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Anand
 */
public class DBConnection {

    private Connection connection;
    private final String driver = "com.mysql.jdbc.Driver";

    private final String username = "root";
    private final String password = "";

    public DBConnection() throws ClassNotFoundException, SQLException {
        String url = "jdbc:mysql://localhost:3306";
        Class.forName(driver);
        connection = DriverManager.getConnection(url, username, password);
    }

    public DBConnection(String database) throws ClassNotFoundException, SQLException {
        System.out.println("Hiiiiiiiiiiiiiiiiiiiiiiii");
        String url = "jdbc:mysql://localhost:3306/" + database;
        Class.forName(driver);
        connection = DriverManager.getConnection(url, username, password);
    }

    public PreparedStatement prepare(String sql) throws SQLException {
        return connection.prepareStatement(sql);
    }

    public PreparedStatement prepare(String sql, boolean flag) throws SQLException {
        if (flag) {
            return connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
        }
        return prepare(sql);
    }

    public void close() throws SQLException {
        connection.close();
    }

}
