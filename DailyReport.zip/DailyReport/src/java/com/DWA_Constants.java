/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author Anand
 */
public class DWA_Constants {
     public static final int WORK_STATUS_ACTIVE=1;
    public static final int WORK_STATUS_PASSIVE=0;
    public static final String JOB_ANALYZER_DB="job_analyzer";
}
