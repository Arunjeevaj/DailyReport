// JS Document created by libu@macmin

function jqUpdateSize()
{
    var width = getWindowWidth();
    var height = getWindowHeight();
    var dimension = width.toString() + " X " + height.toString();
    $('#dim').html(dimension);
}

function getWindowWidth()
{
    var windowWidth = 0;
    if (typeof (window.innerWidth) == 'number')
    {
        windowWidth = window.innerWidth;
    }
    else
    {
        if (document.documentElement && document.documentElement.clientWidth)
        {
            windowWidth = document.documentElement.clientWidth;
        }
        else
        {
            if (document.body && document.body.clientWidth)
            {
                windowWidth = document.body.clientWidth;
            }
        }
    }
    return windowWidth;
}

function getWindowHeight()
{
    var windowHeight = 0;
    if (typeof (window.innerHeight) == 'number')
    {
        windowHeight = window.innerHeight;
    }
    else
    {
        if (document.documentElement && document.documentElement.clientHeight)
        {
            windowHeight = document.documentElement.clientHeight;
        }
        else
        {
            if (document.body && document.body.clientHeight)
            {
                windowHeight = document.body.clientHeight;
            }
        }
    }
    return windowHeight;
}

$(window).resize(function ()
{
    jqUpdateSize();
});

$(document).ready(function ()
{
    jqUpdateSize();


    $("#title").autocomplete({
         minLength: 2,
        source: function (request, response) {
            $.ajax({
                url: 'AutoCompleteTitles',
                type: 'GET',
                data: {term: request.term},
                dataType: 'json',
                success: function (data) {
                    response(data);
                }
            });
        }
    });

    $("#location").autocomplete({
         minLength: 2,
        source: function (request, response) {
            $.ajax({ 
                url: 'AutoCompleteLocation',
                type: 'GET',
                data: {
                    term: request.term
                },
                dataType: 'json',
                success: function (data) {
                    response(data);
                }
            });
        }
    });

    $('#quick_search').click(function (e) {
        if (e.target.id === "quick_search") {
            $('#quick_search').hide();
            document.getElementById("quicksearchform").reset();
        }
    });


    //for user profile navigations
    $('#titleprof').hover(function ()
    {
        $('#psnavwrap').fadeIn();
        $('#plusid').html('-');
    }, function ()
    {
        $('#psnavwrap').fadeOut(100);
        $('#plusid').html('+');
    });

    //for loading message count to header
    if ($("#totmsg").val() != 0)
    {
        $("#messagecount").show();
        $("#messagecount").html($("#totmsg").val());
    }

    if ($("#notifications").val() != 0) {
        $("#notificationCount").show();
        $("#notificationCount").html($("#notifications").val());
    }
});




function quickSearchOverlay()
{
    $("#quick_search").show();
}
function closeOverlay(str)
{
    $("#" + str).hide();
}

function updateExperience(str)
{
    var year = " Years";
    if (str == "minus")
    {
        var exp = $("#experience").val();
        if (exp != "" && exp >= 1)
        {
            if (exp == 1 || exp == 2)
                year = " Year";
            else
                year = " Years";
            $("#experience").val(parseInt(exp) - 1);
            $("#dummyexp").val(parseInt(exp) - 1 + year);
        }
    }
    else
    {
        var exp = $("#experience").val();
        if (exp != "" && exp <= 29)
        {
            if (exp == 0)
                year = " Year";
            else
                year = " Years";
            $("#experience").val(parseInt(exp) + 1);
            $("#dummyexp").val(parseInt(exp) + 1 + year);
        }
        else if (exp == "")
        {
            $("#experience").val(0);
            $("#dummyexp").val(0 + " Year");
        }
    }
}