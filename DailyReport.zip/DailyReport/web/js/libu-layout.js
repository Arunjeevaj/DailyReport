// JS Document created by libu@macmin for hospital theme layout
var userac = 0;
var varwindow1=0, varwindow2=0, varwindow3=0, varwindow4=0, varwindow5=0, varwindow6=0;
$(document).ready(function()
{
	userac=0;
	window1=0, window2=0, window3=0, window4=0, window5=0, window6=0;
	var mainBodyHeight;
	var dashBoardHeight;
	var windowHeight;
	
	mainBodyHeight=$("#mainbody").outerHeight();
	dashBoardHeight=$("#dashboard").outerHeight();
	windowHeight=getWindowHeight();
	
	if(mainBodyHeight<windowHeight-84 && dashBoardHeight<windowHeight-84)
	{
		$("#mainbody").css('height',windowHeight-84);
		$("#dashboard").css('height',windowHeight-84);
	}
	else if(mainBodyHeight>=windowHeight-84 && dashBoardHeight>=windowHeight-84)
	{
		if(mainBodyHeight>dashBoardHeight)
			$("#dashboard").css('height',mainBodyHeight);
		else if(mainBodyHeight<dashBoardHeight)
			$("#mainbody").css('height',dashBoardHeight);
		else{}
	}
	else
	{
		if(mainBodyHeight>dashBoardHeight)
			$("#dashboard").css('height',mainBodyHeight);
		else if(mainBodyHeight<dashBoardHeight)
			$("#mainbody").css('height',dashBoardHeight);
	}
	
	$("#userac").click(function()
	{
		if(userac==0)
		{
			$("#useracwrap").show();
			userac=1;
		}
		else
		{
			$("#useracwrap").hide();
			userac=0;
		}
	});
	
	
	
});

$(window).resize(function()
{	
	var mainBodyHeight;
	var dashBoardHeight;
	var windowHeight;
	
	mainBodyHeight=$("#mainbody").outerHeight();
	dashBoardHeight=$("#dashboard").outerHeight();
	windowHeight=getWindowHeight();
	
	if(mainBodyHeight<windowHeight-84 && dashBoardHeight<windowHeight-84)
	{
		$("#mainbody").css('height',windowHeight-84);
		$("#dashboard").css('height',windowHeight-84);
	}
	else if(mainBodyHeight>=windowHeight-84 && dashBoardHeight>=windowHeight-84)
	{
		if(mainBodyHeight>dashBoardHeight)
			$("#dashboard").css('height',mainBodyHeight);
		else if(mainBodyHeight<dashBoardHeight)
			$("#mainbody").css('height',dashBoardHeight);
		else{}
	}
	else
	{
		if(mainBodyHeight>dashBoardHeight)
			$("#dashboard").css('height',mainBodyHeight);
		else if(mainBodyHeight<dashBoardHeight)
			$("#mainbody").css('height',dashBoardHeight);
	}
});

function hideWindow(str)
{
    $('#'+str+'wrap').slideUp();
    $('#'+str+'up').hide();
    $('#'+str+'down').show();
}
function showWindow(str)
{
    $('#'+str+'wrap').slideDown();
    $('#'+str+'up').show();
    $('#'+str+'down').hide();
}

function closePopup(str)
{
    $('#'+str+'sub').slideUp();
    $('#'+str+'main').fadeOut();
   $("#side-menu").css('display','block');
}
